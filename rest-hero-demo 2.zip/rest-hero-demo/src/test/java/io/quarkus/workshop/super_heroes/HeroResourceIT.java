package io.quarkus.workshop.super_heroes;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class HeroResourceIT extends HeroResourceTest {
    // Execute the same tests but in packaged mode.
}
