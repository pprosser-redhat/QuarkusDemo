package io.quarkus.workshop.super_heroes;

import java.util.List;

import org.eclipse.microprofile.reactive.messaging.Channel;
import org.eclipse.microprofile.reactive.messaging.Emitter;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
//import io.smallrye.reactive.messaging.kafka.Record;

@ApplicationScoped
public class HeroService {

    @Inject
    @Channel ("hero")
    Emitter<Record<Long, String>> emitter;

    public Hero findHeroById(Long id) {
        
        Hero hero = Hero.findById(id);
        emitter.send(Record.of (hero.id, hero.name)); 
        return hero;
    }

    public List<Hero> findAllHeroes(){
        return Hero.listAll();
    }
}
